
import { config } from 'dotenv';
config();

import '@/ai/flows/adaptive-notification-tool.ts';
import '@/ai/flows/support-chat-flow.ts';

