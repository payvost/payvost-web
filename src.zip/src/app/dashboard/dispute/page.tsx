
'use client';

import { useState, useEffect } from 'react';
import type { GenerateNotificationInput } from '@/ai/flows/adaptive-notification-tool';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { FileDown, ListFilter, MoreHorizontal, Search, ShieldQuestion, Target, CircleDollarSign, PlusCircle } from 'lucide-react';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { Progress } from '@/components/ui/progress';
import dynamic from 'next/dynamic';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/hooks/use-auth';
import { db } from '@/lib/firebase';
import { collection, query, where, onSnapshot, DocumentData } from 'firebase/firestore';
import { formatDistanceToNow } from 'date-fns';

const RaiseDisputeForm = dynamic(() => import('@/components/raise-dispute-form').then(mod => mod.RaiseDisputeForm), {
    loading: () => <Skeleton className="h-96 w-full" />,
});


const statusVariant: { [key: string]: 'default' | 'secondary' | 'destructive' | 'outline' } = {
  'Needs response': 'destructive',
  'Under review': 'secondary',
  'Won': 'default',
  'Lost': 'outline',
};

const statusTextClass: { [key: string]: string } = {
    'Won': 'text-green-500',
    'Lost': 'text-muted-foreground',
}

type View = 'list' | 'create';


export default function DisputePage() {
  const [language, setLanguage] = useState<GenerateNotificationInput['languagePreference']>('en');
  const [view, setView] = useState<View>('list');
  const { user } = useAuth();
  const [disputes, setDisputes] = useState<DocumentData[]>([]);
  const [loading, setLoading] = useState(true);

   useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(collection(db, "disputes"), where("userId", "==", user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const disputesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setDisputes(disputesData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching disputes:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const renderDisputesTable = (filteredDisputes: DocumentData[]) => (
    <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Case</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead className="hidden md:table-cell">Reason</TableHead>
              <TableHead className="hidden sm:table-cell">Due By</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
                [...Array(3)].map((_, i) => (
                    <TableRow key={i}>
                        <TableCell colSpan={6}><Skeleton className="h-10 w-full" /></TableCell>
                    </TableRow>
                ))
            ) : filteredDisputes.length > 0 ? filteredDisputes.map((dispute) => (
              <TableRow key={dispute.id}>
                <TableCell>
                  <div className="font-medium">{dispute.caseId}</div>
                  <Badge variant={statusVariant[dispute.status]} className="capitalize mt-1 md:hidden">{dispute.status}</Badge>
                </TableCell>
                <TableCell>
                    <div className="font-medium">{dispute.customerName}</div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                    <div className="flex flex-col">
                        <span>{dispute.reason}</span>
                        <Badge variant={statusVariant[dispute.status]} className="capitalize mt-1 w-fit">{dispute.status}</Badge>
                    </div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">{dispute.dueBy}</TableCell>
                <TableCell className="text-right">{new Intl.NumberFormat('en-US', { style: 'currency', currency: dispute.currency }).format(dispute.amount)}</TableCell>
                <TableCell className="text-right">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                        <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                        </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Submit Evidence</DropdownMenuItem>
                        <DropdownMenuItem>Accept Dispute</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No disputes found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
  );
  
  const renderListView = () => {
    const needsResponseCount = disputes.filter(d => d.status === 'Needs response').length;
    const amountUnderReview = disputes
        .filter(d => d.status === 'Under review')
        .reduce((sum, d) => sum + d.amount, 0);

    return (
    <>
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Dispute Center</h1>
          <Button onClick={() => setView('create')}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Raise a New Dispute
          </Button>
        </div>

        {loading ? (
             <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
                <Skeleton className="h-28 w-full" />
                <Skeleton className="h-28 w-full" />
                <Skeleton className="h-28 w-full" />
            </div>
        ) : disputes.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Needs Response</CardTitle>
                        <ShieldQuestion className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{needsResponseCount}</div>
                        <p className="text-xs text-muted-foreground">Disputes requiring your immediate attention.</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Amount Under Review</CardTitle>
                        <CircleDollarSign className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amountUnderReview)}</div>
                        <p className="text-xs text-muted-foreground">Total value of all open disputes.</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Win Rate (Last 90d)</CardTitle>
                        <Target className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">50%</div>
                        <Progress value={50} className="h-2 mt-2" />
                    </CardContent>
                </Card>
            </div>
        ) : null}

        {!loading && disputes.length === 0 ? (
            <Card className="mt-4">
                <CardContent className="h-96 flex flex-col items-center justify-center text-center">
                    <ShieldQuestion className="h-16 w-16 text-muted-foreground mb-4" />
                    <h3 className="text-2xl font-bold tracking-tight">You have no open disputes</h3>
                    <p className="text-sm text-muted-foreground mb-6">Create a new dispute for a transaction if you have an issue.</p>
                </CardContent>
            </Card>
        ) : (
             <Tabs defaultValue="all">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <TabsList className="overflow-x-auto sm:overflow-visible">
                        <TabsTrigger value="all">All</TabsTrigger>
                        <TabsTrigger value="needs-response">Needs Response</TabsTrigger>
                        <TabsTrigger value="under-review">Under Review</TabsTrigger>
                        <TabsTrigger value="closed">Closed</TabsTrigger>
                    </TabsList>
                    <div className="flex flex-wrap items-center gap-2">
                        <div className="relative flex-1 sm:flex-initial">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                                type="search"
                                placeholder="Search by case ID, email..."
                                className="w-full rounded-lg bg-background pl-8 h-9"
                            />
                        </div>
                        <DateRangePicker className="w-full sm:w-auto" />
                        <Button size="sm" variant="outline" className="h-9 gap-1 w-full sm:w-auto">
                            <FileDown className="h-3.5 w-3.5" />
                            <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">
                            Export
                            </span>
                        </Button>
                    </div>
                </div>
                <div className="mt-4">
                    <Card>
                        <TabsContent value="all">
                            {renderDisputesTable(disputes)}
                        </TabsContent>
                        <TabsContent value="needs-response">
                            {renderDisputesTable(disputes.filter(d => d.status === 'Needs response'))}
                        </TabsContent>
                        <TabsContent value="under-review">
                            {renderDisputesTable(disputes.filter(d => d.status === 'Under review'))}
                        </TabsContent>
                        <TabsContent value="closed">
                            {renderDisputesTable(disputes.filter(d => ['Won', 'Lost'].includes(d.status)))}
                        </TabsContent>
                        <CardFooter>
                            <div className="text-xs text-muted-foreground">
                                Showing <strong>1-{disputes.length}</strong> of <strong>{disputes.length}</strong> disputes
                            </div>
                        </CardFooter>
                    </Card>
                </div>
            </Tabs>
        )}
    </>
  )};

  return (
    <DashboardLayout language={language} setLanguage={setLanguage}>
      <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6">
        {view === 'list' ? renderListView() : <RaiseDisputeForm onBack={() => setView('list')} />}
      </main>
    </DashboardLayout>
  );
}
