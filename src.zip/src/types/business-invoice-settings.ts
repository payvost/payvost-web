

export interface InvoiceSettings {
    defaultFooter?: string;
    enableTax: boolean;
    defaultTaxRate?: number;
    autoInvoiceForRecurring: boolean;
}
