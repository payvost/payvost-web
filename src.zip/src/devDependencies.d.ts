// This file is used to declare modules for packages that don't have TypeScript definitions
// or to extend existing definitions.

// For example, if you have a package named 'some-package' without types:
// declare module 'some-package';
declare module 'react-quill-new';
